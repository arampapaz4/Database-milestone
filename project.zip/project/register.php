<?php
require('connection/db-info.php');

if(isset($_POST['name'])){
	$name = $mysqli->real_escape_string($_POST['name']);
}else{
	die("Don't try to mess around bro ;)");}
if(isset($_POST['password'])){
	$password = hash("sha256",$mysqli->real_escape_string($_POST['password']));
}else{
	die("Don't try to mess around bro ;)");}
	$past="NONE SO FAR";
	$query=$mysqli->prepare('Insert INTO municipalities (name, pastWorks, password) VALUES(?,?,?)');
	$query->bind_param('sss', $name, $past, $password);
	$query->execute();
	
	$_SESSION['created']=TRUE;
	header('Location:index.html');
	
?>