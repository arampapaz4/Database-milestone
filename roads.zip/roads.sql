-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2018 at 10:44 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roads`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `Country` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`Country`, `City`) VALUES
('LEBANON', 'ANTELIAS'),
('LEBANON', 'BEIRUT'),
('LEBANON', 'BYBLOS'),
('LEBANON', 'HARET SAKHRE');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`name`, `location`, `rating`) VALUES
('ATRIA SAL', 'BEIRUT LEBANON', 5),
('BI\'A SARL', 'HARET SAKHRE (KESROUANE), LEBANON', 4),
('M.T.O.S.A.L. MAINTENANCE TECHNIQUE OPTIMISEE', 'ANTELIAS(MATEN),LEBANON', 4),
('PLUS MANAGEMENT & DEVELOPMENT S.A.L.', 'BEIRUT,LEBANON', 3);

-- --------------------------------------------------------

--
-- Table structure for table `companies_has_specialities`
--

CREATE TABLE `companies_has_specialities` (
  `speciality_id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies_has_specialities`
--

INSERT INTO `companies_has_specialities` (`speciality_id`, `company`) VALUES
(1, 'M.T.O.S.A.L MAINTENANCE TECHNIQUE OPTIMISEE'),
(2, 'PLUS MANAGEMENT & DEVELOPMENT  S.A.L.'),
(3, 'BI\'A SARL'),
(4, 'ATRIA SAL');

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `company` varchar(255) NOT NULL,
  `municipality_id` int(11) NOT NULL,
  `since` date NOT NULL,
  `till` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `municipalities`
--

CREATE TABLE `municipalities` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pastWorks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `municipalities`
--

INSERT INTO `municipalities` (`id`, `name`, `pastWorks`) VALUES
(1, 'BYBLOS ', 'NONE SO FAR'),
(2, 'ANTELIAS', 'NONE SO FAR'),
(3, 'BEIRUT', 'NONE SO FAR'),
(4, 'HARET SAKHRE', 'NONE SO FAR');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `since` date NOT NULL,
  `till` date NOT NULL,
  `coordinates` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project_has_resources`
--

CREATE TABLE `project_has_resources` (
  `resources_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `project_has_teams`
--

CREATE TABLE `project_has_teams` (
  `project_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `since` date NOT NULL,
  `till` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `durability` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `resourceType` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`id`, `name`, `durability`, `price`, `stock`, `resourceType`) VALUES
(1, 'CONCRETE', 'GREAT', 200, 10000, 'ROCKS AND MINERALS'),
(2, 'SLATE', 'GREAT', 250, 10000, 'ROCK AND MINERALS'),
(3, 'CONCRETE', 'LOW', 100, 100000, 'ROCK AND MINERALS'),
(4, 'ASPHALT', 'EXCELLENT', 350, 1000, 'HIGHLY VISCOUS CHEMICAL'),
(5, 'GRAVEL', 'GREAT', 150, 10000, 'ROCK FRAGMENTS');

-- --------------------------------------------------------

--
-- Table structure for table `roads`
--

CREATE TABLE `roads` (
  `coordinates` varchar(255) NOT NULL,
  `ratings` int(11) NOT NULL,
  `municipalities_id` int(11) NOT NULL,
  `city` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roads`
--

INSERT INTO `roads` (`coordinates`, `ratings`, `municipalities_id`, `city`) VALUES
('33.891978,35.514781', 4, 3, 'BEIRUT'),
('33.896488,35.517123', 5, 3, 'BEIRUT'),
('34.120698,35.649237', 4, 1, 'BYBLOS'),
('34.123615,35.652815', 2, 1, 'BYBLOS');

-- --------------------------------------------------------

--
-- Table structure for table `specialities`
--

CREATE TABLE `specialities` (
  `speciality` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialities`
--

INSERT INTO `specialities` (`speciality`, `id`) VALUES
('RECONDITIONING, REPAIR & MAINTENANCE SERVICES', 1),
('MANAGEMENT & DEVELOPMENT', 2),
('CIVIL ENGINEERING & PUBLIC WORKS CONSULTANTS', 3),
('ROAD CLEANING CONTRACTORS', 4);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `company` varchar(255) NOT NULL,
  `speciality_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_has_members`
--

CREATE TABLE `team_has_members` (
  `member_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `position` varchar(255) NOT NULL,
  `since` date NOT NULL,
  `till` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`City`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `companies_has_specialities`
--
ALTER TABLE `companies_has_specialities`
  ADD PRIMARY KEY (`speciality_id`,`company`);

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`company`,`municipality_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `municipalities`
--
ALTER TABLE `municipalities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_has_resources`
--
ALTER TABLE `project_has_resources`
  ADD PRIMARY KEY (`resources_id`,`project_id`);

--
-- Indexes for table `project_has_teams`
--
ALTER TABLE `project_has_teams`
  ADD PRIMARY KEY (`project_id`,`team_id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roads`
--
ALTER TABLE `roads`
  ADD PRIMARY KEY (`coordinates`);

--
-- Indexes for table `specialities`
--
ALTER TABLE `specialities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team_has_members`
--
ALTER TABLE `team_has_members`
  ADD PRIMARY KEY (`member_id`,`team_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `municipalities`
--
ALTER TABLE `municipalities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `specialities`
--
ALTER TABLE `specialities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
